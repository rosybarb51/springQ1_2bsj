package com.bitc.number;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringQ12bsjApplicationTests {

	@Test
	void contextLoads() {
	}

}
