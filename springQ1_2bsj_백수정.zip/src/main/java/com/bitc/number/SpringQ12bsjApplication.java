package com.bitc.number;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringQ12bsjApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringQ12bsjApplication.class, args);
	}

}
